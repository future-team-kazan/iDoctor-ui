(function () {
  'use strict';

  angular.module('BlurAdmin.pages.schools')
    .controller('SchoolCtrl', SchoolCtrl);

  /** @ngInject */
  function SchoolCtrl($scope, $stateParams, $state) {
    console.log($stateParams);
    console.log($scope.title);
    $state.current.title = 'Название школы';
    $scope.schoolId = $stateParams.schoolId;
  }

})();